
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function Home() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-4xl font-bold text-blue-600">Skill4Earn</h1>
      <p className="text-lg mt-2 text-gray-700">Learn. Earn. Grow.</p>
      <p className="mt-4 text-gray-600">Empowering students through freelancing & real-world learning.</p>
    </div>
  );
}

function About() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-blue-600">About Skill4Earn</h2>
      <p className="mt-2 text-gray-700">Skill4Earn connects students with freelance opportunities and builds soft skills, leadership, and confidence through real-world projects.</p>
    </div>
  );
}

function HowItWorks() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-blue-600">How It Works</h2>
      <ul className="mt-2 list-disc list-inside text-gray-700">
        <li>Sign up as a student</li>
        <li>Explore available freelance tasks</li>
        <li>Submit work and earn rewards</li>
        <li>Get feedback and mentorship</li>
      </ul>
    </div>
  );
}

function Join() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-blue-600">Join as Student</h2>
      <form className="mt-4 space-y-4">
        <input type="text" placeholder="Full Name" className="border p-2 w-full rounded" />
        <input type="email" placeholder="Email" className="border p-2 w-full rounded" />
        <button className="bg-blue-600 text-white px-4 py-2 rounded">Join Now</button>
      </form>
    </div>
  );
}

function Contact() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-blue-600">Contact Us</h2>
      <p className="mt-2 text-gray-700">Email: support@skill4earn.com</p>
    </div>
  );
}

function App() {
  return (
    <Router>
      <nav className="bg-blue-600 p-4 text-white flex justify-between">
        <span className="font-bold">Skill4Earn</span>
        <div className="space-x-4">
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/how-it-works">How It Works</Link>
          <Link to="/join">Join</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/join" element={<Join />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}

export default App;
