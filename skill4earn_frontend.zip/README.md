# Skill4Earn – Student Freelance Hub

A student-focused freelance opportunity hub built using React and Tailwind CSS.

## Features
- Home, About, Join, Contact pages
- Responsive layout
- React Router navigation

## Getting Started
```bash
npm install
npm start
```

## Deploy
Deploy on [Vercel](https://vercel.com/) or [Netlify](https://netlify.com/).
